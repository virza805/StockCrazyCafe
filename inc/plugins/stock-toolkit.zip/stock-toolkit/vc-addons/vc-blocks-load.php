<?php

//================Vc block load code ==============================
	if( ! defined('ABSPATH' ) ) die('-1');
 	// Class started
 	Class stockVCExtendAddonClass{

 		function __construct(){
 			// we safely integrate with VC with this hook
 			add_action('init', array( $this, 'stockIntegrateWithVC'));
 		}

 		public function stockIntegrateWithVC() {
             // Checks if Visual Composer is not installed
 			if( ! defined( 'WPB_VC_VERSION' ) ){
 				add_action('admin_notices', array( $this, 'stockShowVcVersionNotice' ));
 				return;
             }
             

 			// vissual composer addons
             include  STOCK_ACC_PATH . '/vc-addons/vc-slides.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-logo-carousel.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-service.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-cta.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-stat.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-stock-btn.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-promo-box.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-testimonial-box.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-tile-gallery.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-contact.php';
			 include  STOCK_ACC_PATH . '/vc-addons/vc-projects.php';
			 
			 // Load Stock Default Templates
             include  STOCK_ACC_PATH . '/vc-addons/vc-templates.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-templates-about.php';
             include  STOCK_ACC_PATH . '/vc-addons/vc-templates-works.php';
             			
 			}

 		// show visual composer version
 		public function stockShowVcVersionNotice() {
 			$theme_data = wp_get_theme();
 			echo '
	 			<div class="notice notice-warning">
				    <p>'.sprintf(__('<strong>%s</strong> recommends <strong><a href="'.site_url().'/wp-admin/themes.php?page=tgmpa-install-plugins" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'strock-crazycafe'), $theme_data->get('Name')).'</p>
				</div>
 			';
 		}
 	}

// Finally initialize code
new stockVCExtendAddonClass();