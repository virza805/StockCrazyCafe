<?php

 vc_map(
     array(
        "name" => esc_html__( "Stock Projects", "stock-toolkit" ),
        "base" => "stock_projects",
        "category" => esc_html__( "Stock", "stock-toolkit"),
        "params" => array(
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", "stock-toolkit" ),
                "param_name" => "count",
                "value" => esc_html__( "3", "stock-toolkit" ),
                "description" => esc_html__( "Select project count. If you want to show unlimited project, type -1.", "stock-toolkit" )
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__( "Theme", "stock-toolkit" ),
                    "param_name" => "theme",
                    "std" => esc_html__( "1", "stock-toolkit" ),
                    "value" => array(
                        esc_html__('Left Shorting bar theme', 'stock-toolkit') => 1,
                        esc_html__('Top Shorting bar theme', 'stock-toolkit') => 2,
                        ),
                    "description" => esc_html__( "Select Projects Shorting theme.", "stock-toolkit" )
                )
                // array(
                // "type" => "dropdown",
                // "heading" => esc_html__( "Select project", "stock-toolkit" ),
                // "param_name" => "projectr_id",
                // "value" => stock_toolkit_get_project_as_list(),
                // "description" => esc_html__( "Select project.", "stock-toolkit" ),
                // "dependency" => array(
                //     "element" => "count",
                //     "value" => array("1"),
                //     )
                // ),
                // array(
                //     "type" => "textfield",
                //     "heading" => esc_html__( "projectr Height", "stock-toolkit" ),
                //     "param_name" => "height",
                //     "std" => esc_html__( "730", "stock-toolkit" ),
                //     "description" => esc_html__( "Type project height in px. Numbers only", "stock-toolkit" )
                // ),
                
            )
        )
);

