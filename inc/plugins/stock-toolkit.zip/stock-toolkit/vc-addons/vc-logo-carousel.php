<?php

 vc_map(
     array(
        "name" => esc_html__( "Stock logo carousel", "stock-toolkit" ),
        "base" => "stock_logo_carousel",
        "category" => esc_html__( "Stock", "stock-toolkit"),
        "params" => array(
                array(
                "type" => "attach_images",
                "heading" => esc_html__( "Upload Logo", "stock-toolkit" ),
                "param_name" => "logos",
                "description" => esc_html__( "Input your slides logos. Minimum 6 pic", "stock-toolkit" )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Desktop count", "stock-toolkit" ),
                "param_name" => "desktop_count",
                "std" => esc_html__( "5", "stock-toolkit" ),
                "description" => esc_html__( "Select desktop_count.", "stock-toolkit" )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Tablet count", "stock-toolkit" ),
                "param_name" => "tablet_count",
                "std" => esc_html__( "3", "stock-toolkit" ),
                "description" => esc_html__( "Select tablet_count.", "stock-toolkit" )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Mobile count", "stock-toolkit" ),
                "param_name" => "mobile_count",
                "std" => esc_html__( "2", "stock-toolkit" ),
                "description" => esc_html__( "Select mobile_count.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable loop", "stock-toolkit" ),
                "param_name" => "loop",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select loop.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable autoplay", "stock-toolkit" ),
                "param_name" => "autoplay",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select autoplay.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "LogoCarousel Time", "stock-toolkit" ),
                "param_name" => "autoplayTimeout",
                "std" => esc_html__( "5000", "stock-toolkit" ),
                "value" => array(
                    '1 Second' => '1000',
                    '2 Seconds' => '2000',
                    '3 Seconds' => '3000',
                    '4 Seconds' => '4000',
                    '5 Seconds' => '5000',
                    '6 Seconds' => '6000',
                    '7 Seconds' => '7000',
                    '8 Seconds' => '8000',
                    '9 Seconds' => '9000',
                    '10 Seconds' => '10000',
                    '11 Seconds' => '11000',
                    '12 Seconds' => '12000',
                    '13 Seconds' => '13000',
                    '14 Seconds' => '14000',
                    '15 Seconds' => '15000',
                    ),
                "description" => esc_html__( "Select AutoPlayTimeOut.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "autoplay",
                    "value" => array("true"),
                    )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable navigation", "stock-toolkit" ),
                "param_name" => "nav",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select navigation.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable dots ?", "stock-toolkit" ),
                "param_name" => "dots",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select Dots.", "stock-toolkit" )
                )
            )
        )
);

