<?php

 vc_map(
     array(
        "name" => esc_html__( "Stock Slider", "stock-toolkit" ),
        "base" => "stock_slides",
        "category" => esc_html__( "Stock", "stock-toolkit"),
        "params" => array(
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", "stock-toolkit" ),
                "param_name" => "count",
                "value" => esc_html__( "3", "stock-toolkit" ),
                "description" => esc_html__( "Select slides count. If you want to show unlimited slides, type -1.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Select Slide", "stock-toolkit" ),
                "param_name" => "slider_id",
                "value" => stock_toolkit_get_slide_as_list(),
                "description" => esc_html__( "Select Slide.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("1"),
                    )
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__( "Slider Height", "stock-toolkit" ),
                    "param_name" => "height",
                    "std" => esc_html__( "730", "stock-toolkit" ),
                    "description" => esc_html__( "Type slide height in px. Numbers only", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable loop", "stock-toolkit" ),
                "param_name" => "loop",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select loop.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("2","3","4","5","6","7","8","9","10","11","12","13","14","15"),
                    )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable autoplay", "stock-toolkit" ),
                "param_name" => "autoplay",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select autoplay.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("2","3","4","5","6","7","8","9","10","11","12","13","14","15"),
                    )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Slide Time", "stock-toolkit" ),
                "param_name" => "autoplayTimeout",
                "std" => esc_html__( "5000", "stock-toolkit" ),
                "value" => array(
                    '1 Second' => '1000',
                    '2 Seconds' => '2000',
                    '3 Seconds' => '3000',
                    '4 Seconds' => '4000',
                    '5 Seconds' => '5000',
                    '6 Seconds' => '6000',
                    '7 Seconds' => '7000',
                    '8 Seconds' => '8000',
                    '9 Seconds' => '9000',
                    '10 Seconds' => '10000',
                    '11 Seconds' => '11000',
                    '12 Seconds' => '12000',
                    '13 Seconds' => '13000',
                    '14 Seconds' => '14000',
                    '15 Seconds' => '15000',
                    ),
                "description" => esc_html__( "Select AutoPlayTimeOut.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("2","3","4","5","6","7","8","9","10","11","12","13","14","15"),
                    )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable navigation", "stock-toolkit" ),
                "param_name" => "nav",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select navigation.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("2","3","4","5","6","7","8","9","10","11","12","13","14","15"),
                    )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Enable dots ?", "stock-toolkit" ),
                "param_name" => "dots",
                "std" => esc_html__( "true", "stock-toolkit" ),
                "value" => array(
                    'Yes' => 'true',
                    'No' => 'false',
                    ),
                "description" => esc_html__( "Select Dots.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "count",
                    "value" => array("2","3","4","5","6","7","8","9","10","11","12","13","14","15"),
                    )
                )
            )
        )
);

