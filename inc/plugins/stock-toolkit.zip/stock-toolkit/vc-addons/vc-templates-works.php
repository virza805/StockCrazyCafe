<?php

if( ! defined('ABSPATH' ) ) die('-1');


add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_workpage' ); // Hook in
 
function stock_crazycafe_vc_workpage() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> WorkPage', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list
  //$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url('get_template_directory()/inc/img/About – stock.jpg', __FILE__ ) ); // Always use preg replace to be sure that "space" will not break logic. Thumbnail should have this dimensions: 114x154px
 // $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name

  $data['content']  = <<<CONTENT

  [vc_row][vc_column][stock_projects count="6"][/vc_column][/vc_row][vc_row][vc_column][/vc_column][/vc_row][vc_row][vc_column][stock_projects count="-1" theme="2"][/vc_column][/vc_row]

CONTENT;
  
vc_add_default_templates( $data );
}



