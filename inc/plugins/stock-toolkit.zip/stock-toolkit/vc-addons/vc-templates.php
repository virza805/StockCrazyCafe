<?php

//================ Load Stock Default Templates ==============================

if( ! defined('ABSPATH' ) ) die('-1');


add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_homepage' ); // Hook in
 
function stock_crazycafe_vc_homepage() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> HomePage', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list
 // $data['image_path'] = preg_replace( '/\s/', '%20', plugins_url( 'images/custom_template_thumbnail.jpg', __FILE__ ) ); // Always use preg replace to be sure that "space" will not break logic. Thumbnail should have this dimensions: 114x154px
 // $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name

  $data['content']  = <<<CONTENT
  
  [vc_row full_width="stretch_row_content_no_spaces"][vc_column][stock_slides count="5" autoplaytimeout="1000"][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1591441300024{padding-bottom: 30px !important;background-color: #89c5ed !important;}"][vc_column][stock_logo_carousel logos="53,52,51,50,49,25"][/vc_column][/vc_row][vc_row css=".vc_custom_1593495989995{padding-top: 80px !important;padding-bottom: 20px !important;}"][vc_column][vc_column_text el_class="text-center"]
  <h1 style="text-align: center;">Services we offer.</h1>
  [/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/3"][stock_service_box link_to_page="1959" icon_type="2" title="Statup Business Strategy." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-book" box_background="59"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="145" title="Finance Consultation." desc="Received the likewise law graceful his. Nor might set along with charm..." box_background="66" upload_icon="25"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1957" icon_type="2" title="Insurance Policy." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-handshake-o" box_background="59"][/vc_column][/vc_row][vc_row][vc_column width="1/3"][stock_service_box link_to_page="145" icon_type="2" title="Stock Market Sharing." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-line-chart" box_background="77"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1955" icon_type="2" title="Cloud Service for Business." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-soundcloud" box_background="35"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1948" icon_type="2" title="Business Development." desc="Received the likewise law graceful his. Nor might set along with charm..." box_background="66" choose_icon="fa fa-user"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text el_class="text-center"]
  <h5 style="text-align: center;"><span style="color: #1e8bc3;"><a style="color: #1e8bc3;" href="http://localhost/stock/services-2/"><strong>See all Services</strong></a></span></h5>
  [/vc_column_text][/vc_column][/vc_row][vc_row el_class="text-center" css=".vc_custom_1593495963926{padding-top: 80px !important;padding-bottom: 80px !important;}"][vc_column offset="vc_col-lg-offset-2 vc_col-lg-8"][stock_cta type="2" link_text="Start a project" title="Get a service from us." desc="We offer a free consultation before any project
  ." external_link="vir-za.com"][/vc_column][/vc_row][vc_row full_width="stretch_row" el_class="overlay large-text" css=".vc_custom_1591491825067{padding-top: 60px !important;padding-bottom: 90px !important;background-image: url(http://localhost/stock/wp-content/uploads/2020/05/Shuttarstock_34.jpg?id=35) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column][vc_row_inner][vc_column_inner width="1/2"][vc_column_text]
  <h1>Behind the story.</h1>
  Traveling alteration impression six all uncommonly. Chamber hearing inhabits joy highest private ask him our belief. Up nature valley does...[/vc_column_text][stock_btn link_to_page="42" link_text="Read more about us"][/vc_column_inner][vc_column_inner width="1/2"][vc_single_image image="77" img_size="large" alignment="right"][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/6"][stock_stat number="74" after_text="+" desc="Active clients"][/vc_column_inner][vc_column_inner width="1/6"][stock_stat number="236" after_text="-" desc="Successful projects"][/vc_column_inner][vc_column_inner width="1/6"][stock_stat number="7261" after_text="%" desc="Free consultation"][/vc_column_inner][vc_column_inner width="1/6"][stock_stat number="25" after_text="..." desc="Expert advisors"][/vc_column_inner][vc_column_inner width="1/6"][stock_stat number="99" after_text="%" desc="Success rate"][/vc_column_inner][vc_column_inner width="1/6"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row css=".vc_custom_1591495818826{padding-top: 60px !important;padding-bottom: 80px !important;}"][vc_column width="1/2"][vc_column_text css=".vc_custom_1593412415048{margin-top: 40px !important;}"]
  <h2>Frequently Asked Question.</h2>
  [/vc_column_text][vc_tta_accordion active_section="1" css=".vc_custom_1591495696209{margin-top: 40px !important;}"][vc_tta_section title="How can I start a project with you ?" tab_id="1591495289785-056a23cb-ed54"][vc_column_text]John draws real poor on call my from. May she Mrs furnished discourse extremely. Ask doubt noisy shade guest did build her him. Ignorant repeated hastened it do. Consider bachelor he yourself expenses no. Her itself active giving for expect vulgar months.[/vc_column_text][/vc_tta_section][vc_tta_section title="Do you support any refund policy ?" tab_id="1591495384172-e4c8f0e5-4f5e"][vc_column_text]I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_tta_section][vc_tta_section title="How do you take payments ?" tab_id="1591495379877-edc160f5-8666"][vc_column_text]I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_tta_section][/vc_tta_accordion][/vc_column][vc_column width="1/2"][vc_column_text css=".vc_custom_1593412423889{margin-top: 40px !important;}"]
  <h2>Benefits of us.</h2>
  [/vc_column_text][vc_column_text el_class="large-text"]A country demesne message it. Bachelor domestic extended doubtful as concerns at. Morning prudent removal a letter by. On could my in order never it.[/vc_column_text][vc_row_inner][vc_column_inner width="1/2"][vc_column_text el_class="list-box"]
  <ul>
     <li>Proven results</li>
     <li>Strategy Documentation</li>
     <li>Instant Call Support</li>
  </ul>
  [/vc_column_text][/vc_column_inner][vc_column_inner width="1/2"][vc_column_text el_class="list-box"]
  <ul>
     <li>Expert advisors</li>
     <li>Refund policy</li>
     <li>Free Consultation</li>
  </ul>
  [/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1593411811972{padding-top: 60px !important;padding-bottom: 90px !important;background-color: #f5f8f9 !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column][vc_row_inner][vc_column_inner][vc_column_text]
  <h2 style="text-align: center;">What Customers say</h2>
  [/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner width="1/3"][stock_testimonial_box title="Robin Jonson" position="CEO, MyFinance" photo="123" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence
  chief cause...”"][/vc_column_inner][vc_column_inner width="1/3"][stock_testimonial_box title="Jennifer Jones" position="Founder, World for Women" photo="124" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence
  chief cause...”"][/vc_column_inner][vc_column_inner width="1/3"][stock_testimonial_box title="David Martin" position="Co-founder, Ultimate Solution" photo="126" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence
  chief cause...”"][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner][vc_column_text css=".vc_custom_1593495923666{padding-top: 10px !important;}"]
  <h5 style="text-align: center;"><span style="color: #1e8bc3;"><a style="color: #1e8bc3;" href="http://localhost/stock/testimonial/"><strong><code>Check all testimonials</code></strong></a></span></h5>
  [/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row full_width="stretch_row" el_class="overlay overlay-saym large-text" css=".vc_custom_1593412264870{padding-top: 50px !important;padding-bottom: 40px !important;background-image: url(http://localhost/stock/wp-content/uploads/2020/05/Shuttarstock_34.jpg?id=35) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column][vc_row_inner][vc_column_inner width="7/12" offset="vc_col-lg-offset-3 vc_col-lg-7 vc_col-md-offset-3 vc_col-md-7"][vc_column_text]
  <h2 style="text-align: center;">“ The best preparation for tomorrow is doing your best today. ”</h2>
  [/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row full_width="stretch_row" el_class="bg-left-bottom man-bg" css=".vc_custom_1593078587090{background-image: url(http://localhost/stock/wp-content/uploads/2020/06/Shuttarstock.png?id=106) !important;background-position: 0 0 !important;background-repeat: no-repeat !important;}"][vc_column width="1/2" css=".vc_custom_1593080935155{padding-top: 150px !important;padding-bottom: 50px !important;}" offset="vc_col-lg-offset-6 vc_col-lg-6 vc_col-md-offset-6 vc_col-md-6 vc_col-sm-offset-6"][contact-form-7 id="105"][/vc_column][/vc_row][vc_row full_width="stretch_row_content_no_spaces" css=".vc_custom_1593407297791{margin-top: -60px !important;border-bottom-width: -100px !important;padding-top: -50px !important;}"][vc_column][vc_gmaps link="#E-8_JTNDaWZyYW1lJTIwc3JjJTNEJTIyaHR0cHMlM0ElMkYlMkZ3d3cuZ29vZ2xlLmNvbSUyRm1hcHMlMkZlbWJlZCUzRnBiJTNEJTIxMW0xOCUyMTFtMTIlMjExbTMlMjExZDYzMDQuODI5OTg2MTMxMjcxJTIxMmQtMTIyLjQ3NDY5NjgwMzMwOTIlMjEzZDM3LjgwMzc0NzUyMTYwNDQzJTIxMm0zJTIxMWYwJTIxMmYwJTIxM2YwJTIxM20yJTIxMWkxMDI0JTIxMmk3NjglMjE0ZjEzLjElMjEzbTMlMjExbTIlMjExczB4ODA4NTg2ZTYzMDI2MTVhMSUyNTNBMHg4NmJkMTMwMjUxNzU3YzAwJTIxMnNTdG9yZXklMkJBdmUlMjUyQyUyQlNhbiUyQkZyYW5jaXNjbyUyNTJDJTJCQ0ElMkI5NDEyOSUyMTVlMCUyMTNtMiUyMTFzZW4lMjEyc3VzJTIxNHYxNDM1ODI2NDMyMDUxJTIyJTIwd2lkdGglM0QlMjI2MDAlMjIlMjBoZWlnaHQlM0QlMjI0NTAlMjIlMjBmcmFtZWJvcmRlciUzRCUyMjAlMjIlMjBzdHlsZSUzRCUyMmJvcmRlciUzQTAlMjIlMjBhbGxvd2Z1bGxzY3JlZW4lM0UlM0MlMkZpZnJhbWUlM0U=" css=".vc_custom_1593406736943{border-bottom-width: -40px !important;}"][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}


// About Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_about' ); // Hook in
 
function stock_crazycafe_vc_about() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> About', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
  
  [vc_row css=".vc_custom_1591691908115{padding-top: 40px !important;padding-bottom: 40px !important;}"][vc_column][vc_column_text]
<h3 style="text-align: center;"><em>We are doing this business from</em></h3>
<h3 style="text-align: center;"><em>last 24 years.</em></h3>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591691928264{padding-bottom: 40px !important;}"][vc_column][stock_tile_gallery images="130,132,135,136,137"][/vc_column][/vc_row][vc_row css=".vc_custom_1591693536618{padding-top: 50px !important;}"][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>01.</em></span></h1>
Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.[/vc_column_text][/vc_column][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>02.</em></span></h1>
Doubtful two bed way pleasure confined followed. Shew up ye away no eyes life or were this. Perfectly did suspicion daughters but his intention. It started on society an brought it to explain. Position two saw greatest stronger old. Pianoforte if at simplicity do estimate.[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693546081{padding-bottom: 50px !important;}"][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>03.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>04.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="2/3" offset="vc_col-lg-offset-2 vc_col-lg-8 vc_col-md-offset-2 vc_col-md-8"][vc_video][vc_column_text el_class="large-text" css=".vc_custom_1593422924889{padding-top: 30px !important;}"]
<p style="text-align: center;">Was drawing natural fat respect husband. An as noisy an offer drawn blush place. These tried for way joy wrote witty. In mr began music weeks after at begin. Education no dejection so direction pretended household do to. Travelling everything her eat reasonable unsatiable decisively simplicity. Morning request be lasting it fortune demands highest.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693564173{padding-top: 40px !important;padding-bottom: 30px !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">What Customers say</h2>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693574426{padding-bottom: 50px !important;}"][vc_column width="1/3"][stock_testimonial_box title="Onamica Hasan" position="Web designer" photo="124" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery.
Stairs ladies friend by in mutual a no. hence chief cause...”"][/vc_column][vc_column width="1/3"][stock_testimonial_box title="Tanvir Hasan" position="Web developer" photo="123" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery.
Stairs ladies friend by in mutual a no. hence chief cause...”"][/vc_column][vc_column width="1/3"][stock_testimonial_box title="vir-za.com" position="Developer &amp; Designer" photo="126" testimonial="“Unpacked reserved sir offering bed judgment may and quitting speaking. Is do be an improved raptures offering required in replying raillery.
Stairs ladies friend by in mutual a no. hence chief cause...”"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]
<h5 style="text-align: center;"><a href="http://localhost/stock/testimonial/"><span style="color: #278cc1;">See all testimonial</span></a></h5>
[/vc_column_text][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}


// Services Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_services' ); // Hook in
 
function stock_crazycafe_vc_services() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> Services', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
  
  [vc_row css=".vc_custom_1593487019305{padding-top: 100px !important;padding-bottom: 50px !important;}"][vc_column][vc_column_text]
  <h1 style="text-align: center;">Our Services.</h1>
  [/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/3"][stock_service_box link_to_page="1959" icon_type="2" title="Statup Business Strategy." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-book" box_background="59"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="145" title="Finance Consultation." desc="Received the likewise law graceful his. Nor might set along with charm..." box_background="66" upload_icon="25"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1957" icon_type="2" title="Insurance Policy." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-handshake-o" box_background="59"][/vc_column][/vc_row][vc_row][vc_column width="1/3"][stock_service_box link_to_page="145" icon_type="2" title="Stock Market Sharing." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-line-chart" box_background="77"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1955" icon_type="2" title="Cloud Service for Business." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-soundcloud" box_background="35"][/vc_column][vc_column width="1/3"][stock_service_box link_to_page="1948" icon_type="2" title="Business Development." desc="Received the likewise law graceful his. Nor might set along with charm..." box_background="66" choose_icon="fa fa-user"][/vc_column][/vc_row][vc_row][vc_column width="1/2"][stock_service_box type="2" icon_type="2" title="Graphics Design for Website" desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-ravelry" box_background="136" external_link="sbgs.vir-za.com"][/vc_column][vc_column width="1/2"][stock_service_box type="2" icon_type="2" title="Web development with SEO." desc="Received the likewise law graceful his. Nor might set along with charm..." choose_icon="fa fa-code" box_background="1984" external_link="vir-za.com"][/vc_column][/vc_row][vc_column][/vc_column]

CONTENT;
  
  vc_add_default_templates( $data );
}

// Works Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_work' ); // Hook in
 
function stock_crazycafe_vc_work() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> Works', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
  
  [vc_row css=".vc_custom_1593424183314{padding-top: 100px !important;padding-bottom: 50px !important;}"][vc_column][vc_column_text]
  <h2 style="text-align: center;"><span style="color: #339966;"><em><strong>Style One</strong></em></span></h2>
  [/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][stock_projects count="6"][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]
  <h2 style="text-align: center;"><span style="color: #339966;"><em><strong>Style Two</strong></em></span></h2>
  [/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][stock_projects count="-1" theme="2"][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}

// Career Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_career' ); // Hook in
 
function stock_crazycafe_vc_career() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> Career', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
 

  [vc_row css=".vc_custom_1593423433730{padding-top: 10px !important;}"][vc_column width="2/3" offset="vc_col-lg-offset-3 vc_col-lg-7 vc_col-md-offset-3 vc_col-md-7" css=".vc_custom_1593423480841{margin-top: 65px !important;}"][stock_cta link_to_page="2" link_text="See open jobs" title="It's awesome to work with us" desc="Admiration we surrounded possession frequently. Remarkably did increase occasionally too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be.
."][vc_video css=".vc_custom_1591503491205{padding-top: 45px !important;padding-bottom: 75px !important;}"][/vc_column][/vc_row][vc_row][vc_column width="1/3"][stock_promo_box type="2" title="UX Designer" desc="Savar Dhaka, BD
." external_link="vir-za.com"][/vc_column][vc_column width="1/3"][stock_promo_box type="2" title="Finance Manager" desc="Dhaka, Bangladesh.
." external_link="vir-za.com"][/vc_column][vc_column width="1/3"][stock_promo_box link_to_page="2" title="Project Manager" desc="Remote.
."][/vc_column][/vc_row][vc_row css=".vc_custom_1591503596455{margin-top: 30px !important;margin-bottom: 75px !important;}"][vc_column width="1/3"][stock_promo_box type="2" title="Logo Designer" desc="Savar Dhaka, BD
." external_link="vir-za.com"][/vc_column][vc_column width="1/3"][stock_promo_box type="2" title="Graphics Designer" desc="Dhaka, Bangladesh.
." external_link="vir-za.com"][/vc_column][vc_column width="1/3"][stock_promo_box type="2" title="Web Developer &amp; SEO" desc="Savar Dhaka-1340
." external_link="vir-za.com"][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1591523717212{background-color: #f5f8f9 !important;}"][vc_column][vc_row_inner css=".vc_custom_1591525745858{padding-top: 30px !important;}"][vc_column_inner][vc_column_text]
<h1 style="text-align: center;">What customers say</h1>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1591525771840{margin-top: 40px !important;margin-bottom: 40px !important;}"][vc_column_inner width="1/3"][stock_testimonial_box title="Tanvir Hasan" position="Design for Website" photo="77" testimonial="Design for Website Design for Website Design for WebsiteDesign for Website......"][/vc_column_inner][vc_column_inner width="1/3"][stock_testimonial_box title="Tanvir Hasan" position="Design for Website" photo="59" testimonial="Design for Website Design for Website Design for WebsiteDesign for Website......n for Website Design for WebsiteDesign for Website......n for Website Design for WebsiteDesign for Website......"][/vc_column_inner][vc_column_inner width="1/3"][stock_testimonial_box title="Tanvir Hasan" position="Design for Website" photo="66" testimonial="Design for Website Design for Website Design for WebsiteDesign for Website......"][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1591525898746{padding-top: 5px !important;padding-bottom: 30px !important;}"][vc_column_inner][vc_column_text]
<h5 style="text-align: center;"><strong><a href="http://localhost/stock/testimonial/"><span style="color: #339966;">Check all</span> <span style="color: #339966;">testimonials</span></a></strong></h5>
<!--more-->[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}

// Contact Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_contact' ); // Hook in
 
function stock_crazycafe_vc_contact() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> Contact', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
  
  [vc_row css=".vc_custom_1593494302145{padding-top: 100px !important;padding-bottom: 50px !important;}"][vc_column width="1/2"][vc_column_text]
  <h2 style="text-align: left;"><strong>Send us a message</strong></h2>
  <p style="text-align: left;">Questions explained agreeable preferred strangers too him. Set put shyness offices his females him distant.</p>
  [/vc_column_text][/vc_column][vc_column width="1/2"][/vc_column][/vc_row][vc_row][vc_column width="1/2"][contact-form-7 id="2130"][/vc_column][vc_column width="1/2" css=".vc_custom_1593494420557{padding-top: 20px !important;padding-left: 40px !important;}"][stock_contact type="2" icon_type="2" link_text="call" title="virza805@gmail.com" desc="Send us an email" external_link="mailto:virza805@gmail.com" choose_icon="fa fa-envelope" box_background="1983"][stock_contact type="2" icon_type="2" link_text="" title="+8801795815660" desc="Give us a call" external_link="tel:+8801795815660" choose_icon="fa fa-phone" box_background="1984"][stock_contact link_to_page="2" icon_type="2" link_text="call" title="Mon - Fri, 9am - 6pm" desc="We are open" choose_icon="fa fa-clock-o" box_background="135"][stock_contact type="2" link_text="call" title="A, 63/4 Saver Dhaka - 1340, Bangladesh" desc="Meet us here" external_link="https://www.google.com.bd/maps/@23.8196926,90.2726876,13z?hl=en&amp;authuser=0" box_background="1687" upload_icon="1983"][stock_contact type="2" icon_type="2" link_text="call" title="vir-za.com" desc="Our web address." external_link="https://www.vir-za.com" box_background="1983" choose_icon="fa fa-globe"][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}


// services_details Tampleat

add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_services_details' ); // Hook in
 
function stock_crazycafe_vc_services_details() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> Services_details', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list

  $data['content']  = <<<CONTENT
  
  [vc_row css=".vc_custom_1593413789045{padding-top: 100px !important;padding-bottom: 100px !important;}"][vc_column width="1/4"][vc_wp_custommenu nav_menu="3"][stock_cta type="2" theme="2" link_text="Request A Call" title="Get a free call" desc="Sportsman delighted improving dashwoods gay instantly happiness six. Ham now amounted absolute not mistaken way pleasant whatever." external_link="tel:+8801795815660"][/vc_column][vc_column width="3/4"][vc_column_text el_class="list-box"]Finance Consultation on call my from. May she Mrs furnished discourse extremely. Ask doubt noisy shade guest did build her him. Ignorant repeated hastened it do. Consider bachelor he yourself expenses no. Her itself active giving for expect vulgar months.

<hr />

<h4>Benefits of Finance Consultation</h4>
Finance Consultation on call my from. May she Mrs furnished discourse extremely.
<ul>
 	<li> Continued at up to zealously necessary breakfast.</li>
 	<li> Day either Mrs talent pulled men rather regret to admire.</li>
 	<li> Principles man any insipidity age you simplicity.</li>
</ul>
&nbsp;

<img class=" wp-image-77 aligncenter" src="http://localhost/stock/wp-content/uploads/2020/06/Shuttarstock_33.jpg" alt="" width="1022" height="493" />

Betrayed cheerful declared end and. Questions we additions are extremely incommoded. Next half add call them to eat face. Age lived smile six defer bed their few. Had admitting concluded to behavior him she. Of death to or to being other.[/vc_column_text][vc_row_inner][vc_column_inner][vc_column_text]
<h2>Frequently Asked Question.</h2>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_tta_accordion][vc_tta_section title="How can I start a project with you ?" tab_id="1591696150771-7e76c51d-5c7c"][vc_column_text]John draws real poor on call my from. May she Mrs furnished discourse extremely. Ask doubt noisy shade guest did build her him. Ignorant repeated hastened it do. Consider bachelor he yourself expenses no. Her itself active giving for expect vulgar months.[/vc_column_text][/vc_tta_section][vc_tta_section title="How do you take payments ?" tab_id="1591696219778-2e078a4c-d5f6"][vc_column_text]I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_tta_section][vc_tta_section title="Do you support any refund policy ?" tab_id="1591696216796-aa86fe68-a5a6"][vc_column_text]John draw real poor on call my from. May she mrs furnished discourse extremely. Ask doubt noisy shade guest did built her him. Ignorant repeated hastened it do. Consider bachelor he yourself expenses no. Her itself active giving for expect vulgar months.[/vc_column_text][/vc_tta_section][/vc_tta_accordion][/vc_column][/vc_row]

CONTENT;
  
  vc_add_default_templates( $data );
}




