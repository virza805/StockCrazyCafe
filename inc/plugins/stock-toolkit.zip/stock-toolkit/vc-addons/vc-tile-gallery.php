<?php


 vc_map(
     array(
        "name" => __( "Stock tile gallery", "my-text-domain" ),
        "base" => "stock_tile_gallery",
        "category" => __( "Stock", "my-text-domain"),
        "params" => array(
                array(
                "type" => "attach_images",
                "heading" => __( "Upload gallery images", "my-text-domain" ),
                "param_name" => "images",
                "description" => __( "Input your Gallery images", "my-text-domain" )
                ),
                array(
                "type" => "textfield",
                "heading" => __( "Height", "my-text-domain" ),
                "param_name" => "height",
                "std" => __( "310", "my-text-domain" ),
                "description" => __( "Type image height in number.", "my-text-domain" )
                )
                
            )
        )
);

