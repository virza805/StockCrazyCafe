<?php 

// if( ! defined('ABSPATH' ) ) die('-1');


add_action( 'vc_load_default_templates_action','stock_crazycafe_vc_aboutpage' ); // Hook in
 
function stock_crazycafe_vc_aboutpage() {
  $data = array(); // Create new array
  $data['name'] = __( 'Stock -> AboutPage', 'my-text-domain' ); // Assign name for your custom template
  $data['weight'] = 0; // Weight of your template in the template list
  //$data['image_path'] = preg_replace( '/\s/', '%20', plugins_url('/vc-addons/img/about-stock.jpg', __FILE__ ) ); // Always use preg replace to be sure that "space" will not break logic. Thumbnail should have this dimensions: 114x154px
 // $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name

  $data['content']  = <<<CONTENT
  [vc_row css=".vc_custom_1591691908115{padding-top: 40px !important;padding-bottom: 40px !important;}"][vc_column][vc_column_text]
<h3 style="text-align: center;"><em>We are doing this business from</em></h3>
<h3 style="text-align: center;"><em>last 24 years.</em></h3>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591691928264{padding-bottom: 40px !important;}"][vc_column][stock_tile_gallery images="130,132,135,136,137"][/vc_column][/vc_row][vc_row css=".vc_custom_1591693536618{padding-top: 50px !important;}"][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>01.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>02.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693546081{padding-bottom: 50px !important;}"][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>03.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][vc_column width="1/2"][vc_column_text el_class="large-text"]
<h1><span style="color: #278cc1;"><em>04.</em></span></h1>
I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="2/3" offset="vc_col-lg-offset-2 vc_col-lg-8 vc_col-md-offset-2 vc_col-md-8"][vc_video][vc_column_text el_class="large-text" css=".vc_custom_1591693519193{padding-top: 30px !important;}"]
<p style="text-align: center;">I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693564173{padding-top: 40px !important;padding-bottom: 30px !important;}"][vc_column][vc_column_text]
<h2 style="text-align: center;">What Customers say</h2>
[/vc_column_text][/vc_column][/vc_row][vc_row css=".vc_custom_1591693574426{padding-bottom: 50px !important;}"][vc_column width="1/3"][stock_testimonial_box title="Onamica Hasan" position="Web designer" photo="124" testimonial="Raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence chief cause"][/vc_column][vc_column width="1/3"][stock_testimonial_box title="Tanvir Hasan" position="Web developer" photo="123" testimonial="Raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence chief cause"][/vc_column][vc_column width="1/3"][stock_testimonial_box title="vir-za.com" position="Developer &amp; Designer" photo="126" testimonial="Raptures offering required in replying raillery. Stairs ladies friend by in mutual a no. hence chief cause"][/vc_column][/vc_row]


CONTENT;
  
vc_add_default_templates( $data );
}



