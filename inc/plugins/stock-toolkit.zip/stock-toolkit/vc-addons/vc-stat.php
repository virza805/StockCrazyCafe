<?php

 vc_map(
     array(
        "name" => __( "Stock statics box", "stock-toolkit" ),
        "base" => "stock_stat",
        "category" => __( "Stock", "stock-toolkit"),
        "params" => array(
                array(
                "type" => "textfield",
                "heading" => __( "Statics number", "stock-toolkit" ),
                "param_name" => "number",
                "description" => __( "Wright statics number.", "stock-toolkit" ),
                ),
                array(
                "type" => "textfield",
                "heading" => __( "Statics number after text", "stock-toolkit" ),
                "param_name" => "after_text",
                "description" => __( "Wright statics number after text.", "stock-toolkit" ),
                ),
                array(
                "type" => "textfield",
                "heading" => __( "Statics description", "stock-toolkit" ),
                "param_name" => "desc",
                "description" => __( "Wright statics description.", "stock-toolkit" ),
                ),
               
            )
        )
);

