<?php 
/*
Plugin Name: StockToolKit
Author: Tanvir Hasan
Version: 1.0
*/
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// Define
define( 'STOCK_ACC_URL', WP_PLUGIN_URL . '/' . plugin_basename( dirname( __FILE__ ) ) . '/' );
define( 'STOCK_ACC_PATH', plugin_dir_path( __FILE__ ) );

// How to SlidePost according to list-style...function
function stock_toolkit_get_slide_as_list() {
    $args = wp_parse_args( array(
        'post_type' => 'slide',
        'numberposts' => -1,
    ));

    $posts = get_posts( $args );

    $post_options = array(esc_html__('-- Select Slide --', 'stock-toolkit')=> '');
    if( $posts ){
        foreach ( $posts as $post ) {
            $post_options[ $post->post_title ] = $post->ID;
        }
    }
    return $post_options;
} 
// How to SlidePost according to list-style...function
function stock_toolkit_get_page_as_list() {
    $args = wp_parse_args( array(
        'post_type' => 'page',
        'numberposts' => -1,
    ));

    $posts = get_posts( $args );

    $post_options = array(esc_html__('-- Select Page --', 'stock-toolkit')=> '');
    if( $posts ){
        foreach ( $posts as $post ) {
            $post_options[ $post->post_title ] = $post->ID;
        }
    }
    return $post_options;
} 
 // ######## >>>> Custom Post Register <<<< ########
add_action( 'init', 'stock_toolkit_custom_post' );
function stock_toolkit_custom_post() {
    // For Slider
    register_post_type( 'slide',
    array(
        'labels' => array(
            'name' => esc_html__('Slides', 'stock-toolkit'),
            'singular_name' => esc_html__('Slide', 'stock-toolkit')
        ),
        'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
        'public' => false,
        'show_ui' => true,
        )
    );
    // For OurWork/Project
    register_post_type( 'project',
    array(
        'labels' => array(
            'name' => __('Projects'),
            'singular_name' => __('Project')
        ),
        'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
        'public' => true,
        )
    );
}

// ######## >>>> Custom Post-taxonomy Register <<<< ########
function stock_toolkit_custom_post_taxonomy() {
    register_taxonomy(
        'project_cat',  
        'project',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Project Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'project-category', 
                'with_front'    => true 
                )
            )
    );
}
add_action( 'init', 'stock_toolkit_custom_post_taxonomy');



// print shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

// Loading VC addons
 require_once( STOCK_ACC_PATH . 'vc-addons/vc-blocks-load.php' );


// Theme ShortCodes
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/slides-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/logo-carousel-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/service-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/cta-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/stat-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/stock-btn-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/promo-box-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/testimonial-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/styled-map-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/tile-gallery-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/contact-shortcode.php' );
 require_once( STOCK_ACC_PATH . 'theme-shortcodes/projects-shortcode.php' );

// Shortcodes depended on Visual Composer
include_once( ABSPATH .'wp-admin/includes/plugin.php' );
if (is_plugin_active('js_composer/js_composer.php')) {
    // require_once( STOCK_ACC_PATH . 'theme-shortcodes/staff-shortcode.php' );
}

// Registering stock toolkit files
function stock_toolkit_files() {

    wp_enqueue_style('owl-carousel', plugin_dir_url(__FILE__) . 'assets/css/owl.carousel.css');
    wp_enqueue_style('stock-toolkit', plugin_dir_url(__FILE__) . 'assets/css/stock-toolkit.css');
    wp_enqueue_script('owl-carousel', plugin_dir_url(__FILE__) . 'assets/js/owl.carousel.min.js', array('jquery'), '20120206', true );
    wp_enqueue_script('gmap3', plugin_dir_url(__FILE__) . 'assets/js/gmap3.min.js', array('jquery'), '20120206', true );
    wp_enqueue_script('isotope', plugin_dir_url(__FILE__) . 'assets/js/isotope-3.0.6.pkgd.min.js', array('jquery'), '20120206', true );
    // wp_enqueue_script('jquery-1.10', plugin_dir_url(__FILE__) . 'assets/js/jquery-1.10.2.min.js', array('jquery'), '20120206', true );
    // wp_enqueue_script('waypoints', plugin_dir_url(__FILE__) . 'assets/js/waypoints.min-v2.0.3.js', array('jquery'), '20120206', true );
    // wp_enqueue_script('counterup', plugin_dir_url(__FILE__) . 'assets/js/jquery.counterup.min.js', array('jquery'), '20120206', true );
    // ami pora Counterup korbo May be gmap3 এর মত করবো । ভিডিও ২০ নাম্বার 
}
add_action('wp_enqueue_scripts', 'stock_toolkit_files');




?>