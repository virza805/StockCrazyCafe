<?php 


function stock_testimonial_box_shortcode($atts, $content = null) {

    extract( shortcode_atts( array(
        'title' => '',
        'position' => '',
        'testimonial' => '',
        'photo' => '',
    ), $atts));

    if($type == 1){
        $link_source = get_page_link($link_to_page);
    }else{
        $link_source = $external_link;
    }

    $photo_array = wp_get_attachment_image_src($photo, 'large');

    $testimonial_allowed_tags = array(
        'a' => array(
            'href' => array(),
            'title' => array(),
            'class' => array()
        ),
        'img' => array(
            'alt' => array(),
            'src' => array()
        ),
        'br' => array(),
        'em' => array(),
        'strong' => array(),
    );

    $stock_testimonial_box_markup = '
        <div class="stock-testimonial-box">
            <img src="'.esc_url($photo_array[0]).'" alt="'.esc_html($title).'">
            <h3>'.esc_html($title).' <span>'.esc_html($position).'</span></h3>
            '.wp_kses(wpautop($testimonial), $testimonial_allowed_tags).'
        </div>';

    return $stock_testimonial_box_markup;

}
add_shortcode('stock_testimonial_box', 'stock_testimonial_box_shortcode');
