<?php 


function stock_contact_shortcode($atts, $content = null) {

    extract( shortcode_atts( array(
        'title' => '',
        'desc' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        'link_text' => 'See more',
        'icon_type' => 1,
        'upload_icon' => '',
        'choose_icon' => '',
        'box_background' => '',
    ), $atts));

    if($type == 1){
        $link_source = get_page_link($link_to_page);
    }else{
        $link_source = $external_link;
    }

    $box_bg_array = wp_get_attachment_image_src($box_background, 'medium');

    $stock_contact_markup = '
        <div class="stock-service-box">
            <div style="background-image:url('.esc_url($box_bg_array[0]).')" class="stock-service-icon">
                <div class="stock-service-table">
                    <div class="stock-service-tablecell">';

     if($icon_type == 1){
        $service_icon_array = wp_get_attachment_image_src($upload_icon, 'thumbnail');
        $stock_contact_markup .= '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
    }else{
        $stock_contact_markup .= '<i class="'.esc_attr($choose_icon).'"></i>';
    }

    $stock_cta_desc_allowed_tags = array(
        'a' => array(
            'href' => array(),
            'title' => array(),
            'class' => array()
        ),
        'img' => array(
            'alt' => array(),
            'src' => array()
        ),
        'br' => array(),
        'em' => array(),
        'strong' => array(),
    );

    $stock_contact_markup .= '
                    </div>
                </div>
            </div>

            <div class="stock-service-content">
                
                '.wp_kses(wpautop($desc), $stock_cta_desc_allowed_tags).'
                <a href="'.esc_url($link_source).'" class="service-more-btn text-dark">
                    <h3>'.esc_html($title).'</h3>
                </a>
                
            </div>
        </div>
    ';

    return $stock_contact_markup;

}
add_shortcode('stock_contact', 'stock_contact_shortcode');
