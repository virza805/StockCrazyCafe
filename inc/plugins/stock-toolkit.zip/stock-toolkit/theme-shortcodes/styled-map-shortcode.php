<?php 


function stock_styled_map_shortcode($atts, $content = null) {

    extract( shortcode_atts( array(
        'title' => '',
    ), $atts));

    $stock_styled_map_markup = '
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBQoPa5_MLa-lbP-xJ7KeWUbjTTLVqPE6Q&region=US"></script>

    <div style="width:100%; height: 500px;" class="map"></div>
    <script>
      jQuery(document).ready(function($){
      $(".map")
        .gmap3({
          center:[41.850033, -87.650052],
          zoom:12,
          mapTypeId: "shadeOfGrey", // to select it directly
          mapTypeControlOptions: {
            mapTypeIds: [google.maps.MapTypeId.ROADMAP, "shadeOfGrey"]
          }
        })
        .styledmaptype(
          "shadeOfGrey",
          [
            {"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},
            {"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},
            {"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},
            {"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},
            {"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},
            {"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},
            {"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},
            {"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},
            {"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},
            {"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},
            {"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},
            {"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},
            {"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}
          ],
          {name: "Shades of Grey"}
        );
    });
    </script>
    ';

    return $stock_styled_map_markup;

}
add_shortcode('stock_styled_map', 'stock_styled_map_shortcode');
