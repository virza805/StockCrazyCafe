<?php 


function stock_stat_shortcode($atts, $content = null) {

    extract( shortcode_atts( array(
        
        'number' => '',
        'after_text' => '',
        'desc' => '',
    ), $atts));


    $stock_stat_markup = "
    <script>
        jQuery(document).ready(function( $ ) {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        });
    </script>
    ";
    // you can see s_72 RRF for CounterUp
    $stock_stat_markup = '
        <div class="stock-stat-box">
            <h1><span class="counter">'.esc_html($number).'</span>'.esc_html($after_text).'</h1>
            '.esc_html($desc).'
        </div>
    ';

    return $stock_stat_markup;

}
add_shortcode('stock_stat', 'stock_stat_shortcode');
